- Double click download_demo.bat to download Demo3.14

- Double-click Nanoquake.bat and then choose option "1.Start the Game" to launch Nanoquake

for more up to date info please visit https://github.com/Nanoquake/yquake2/wiki